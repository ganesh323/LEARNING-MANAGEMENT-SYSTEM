# Canvas_LMS
Learning management system using MERN stack, Kafka


A) Basic Users (Student & faculty) functionalities:
1. Sign up new user (Name, Email and password)
2. Sign in existing user
3. Sign out.
4. Profile (Profile Image, Name, Email, Phone Number, About Me, City, Country, Company, School, Hometown, Languages, Gender)
5. Users can update Profile anytime.

B) Faculty
1. Only the Faculty can create course with fields CourseId, CourseName, Course Dept, description, CourseRoom, Waitlist Capacity, CourseTeam.

C) Home
1. Student can view all the courses he/she has registered.
2. Faculty can view all the courses created by them.


